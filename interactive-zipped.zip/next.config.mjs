/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['gimgs2.nohat.cc', 'res.cloudinary.com'],
  },
};

export default nextConfig;
